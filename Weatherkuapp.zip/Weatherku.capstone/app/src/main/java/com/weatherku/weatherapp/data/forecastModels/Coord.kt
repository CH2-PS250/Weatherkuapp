package com.com.weatherku.weatherapp.data.forecastModels

data class Coord(
    val lat: Double,
    val lon: Double
)