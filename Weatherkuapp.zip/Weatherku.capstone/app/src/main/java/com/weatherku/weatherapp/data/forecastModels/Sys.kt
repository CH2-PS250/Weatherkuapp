package com.weatherku.weatherapp.data.forecastModels

data class Sys(
    val pod: String
)