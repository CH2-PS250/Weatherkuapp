package com.weatherku.weatherapp.data.models

data class Clouds(
    val all: Int
)