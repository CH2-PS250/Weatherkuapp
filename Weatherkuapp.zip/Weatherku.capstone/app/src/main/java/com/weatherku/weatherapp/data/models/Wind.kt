package com.weatherku.weatherapp.data.models

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)