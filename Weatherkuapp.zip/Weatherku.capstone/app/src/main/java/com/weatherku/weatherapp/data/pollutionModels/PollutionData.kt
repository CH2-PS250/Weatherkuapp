package com.weatherku.weatherapp.data.pollutionModels

import com.weatheru.weatherapp.data.pollutionModels.Pollution

data class PollutionData(

    val coord: Coord,
    val list: List<Pollution>
)