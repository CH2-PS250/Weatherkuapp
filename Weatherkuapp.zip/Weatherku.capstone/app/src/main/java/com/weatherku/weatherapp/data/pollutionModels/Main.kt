package com.weatherku.weatherapp.data.pollutionModels

data class Main(
    val aqi: Int
)