package com.weatherku.weatherapp.data.models

data class Coord(
    val lat: Double,
    val lon: Double
)