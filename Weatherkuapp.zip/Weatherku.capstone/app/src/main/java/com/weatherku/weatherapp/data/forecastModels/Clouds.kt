package com.weatherku.weatherapp.data.forecastModels

data class Clouds(
    val all: Int
)