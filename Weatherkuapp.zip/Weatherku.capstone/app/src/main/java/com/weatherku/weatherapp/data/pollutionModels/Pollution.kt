package com.weatheru.weatherapp.data.pollutionModels

import ccom.weatherku.weatherapp.data.pollutionModels.Components
import com.weatherku.weatherapp.data.pollutionModels.Main

data class Pollution(
    val main: Main,
    val components: Components,
    val dt: Int,
)