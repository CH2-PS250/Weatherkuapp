package com.weatherku.weatherapp.config


import com.weatherku.weatherapp.data.ApiInterface
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiInterface {
    companion object{
        fun getApiInterface(): ApiInterface {

            val retrofit = Retrofit.Builder()
                .baseUrl("https://cloudbyme-mobile-api-uwqh6vjbhq-et.a.run.app/weather/kalimantan-selatan")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            return retrofit.create(ApiInterface::class.java)
        }
    }
}