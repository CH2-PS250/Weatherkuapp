package com.weatherku.weatherapp.utils

object Util {

    const val Base = "https://api.openweathermap.org/data/2.5/"
}